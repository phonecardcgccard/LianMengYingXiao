// src/app/sitemap.ts
import { MetadataRoute } from "next";

// Placeholder product IDs - in a real app, fetch these dynamically
const productIds = ["1", "2", "3", "4"];
const siteUrl = "https://your-production-domain.com"; // Replace with your actual domain

export default function sitemap(): MetadataRoute.Sitemap {
  const languages = ["en", "zh"];
  const pages = ["", "/products"];

  let sitemapEntries: MetadataRoute.Sitemap = [];

  languages.forEach(lang => {
    // Add static pages
    pages.forEach(page => {
      sitemapEntries.push({
        url: `${siteUrl}${lang === "en" ? "" : "/" + lang}${page}`,
        lastModified: new Date(),
        changeFrequency: "weekly",
        priority: page === "" ? 1 : 0.8,
        alternates: {
          languages: {
            en: `${siteUrl}${page}`,
            zh: `${siteUrl}/zh${page}`,
          },
        },
      });
    });

    // Add dynamic product pages
    productIds.forEach(id => {
      sitemapEntries.push({
        url: `${siteUrl}${lang === "en" ? "" : "/" + lang}/products/${id}`,
        lastModified: new Date(),
        changeFrequency: "daily",
        priority: 0.7,
        alternates: {
          languages: {
            en: `${siteUrl}/products/${id}`,
            zh: `${siteUrl}/zh/products/${id}`,
          },
        },
      });
    });
  });

  return sitemapEntries;
}

