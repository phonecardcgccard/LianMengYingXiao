import Link from 'next/link';
import { notFound } from 'next/navigation';

// Placeholder for product data - in a real app, this would come from a database or API
const products = [
  { id: '1', name: 'Rose Quartz', category: 'Healing Crystals', price: '25.99', image: '/images/rose-quartz.jpg', description: 'Rose Quartz is the stone of universal love. It restores trust and harmony in relationships, encouraging unconditional love.' },
  { id: '2', name: 'Amethyst Cluster', category: 'Decorative Crystals', price: '45.50', image: '/images/amethyst-cluster.jpg', description: 'Amethyst is a powerful and protective stone. It guards against psychic attack, transmuting the energy into love and protecting the wearer from all types of harm.' },
  { id: '3', name: 'Clear Quartz Point', category: 'Energy Crystals', price: '18.75', image: '/images/clear-quartz-point.jpg', description: 'Clear Quartz is known as the master healer and will amplify energy and thought, as well as the effect of other crystals.' },
  { id: '4', name: 'Citrine Geode', category: 'Abundance Crystals', price: '62.00', image: '/images/citrine-geode.jpg', description: 'Citrine attracts wealth, prosperity and success. It imparts joy, wonder, delight and enthusiasm.' },
  { id: '5', name: 'Black Tourmaline', category: 'Protection Crystals', price: '33.25', image: '/images/black-tourmaline.jpg', description: 'Black Tourmaline is a protective stone which repels and blocks negative energies and psychic attack. Black Tourmaline also aids in the removal of negative energies within a person or a space.' }
];

interface ProductDetailsPageProps {
  params: {
    id: string;
  };
}

export default function ProductDetailsPage({ params }: ProductDetailsPageProps) {
  const product = products.find((p) => p.id === params.id);

  if (!product) {
    notFound();
  }

  return (
    <div style={{padding: '20px', maxWidth: '800px', margin: '0 auto'}}>
      <div style={{marginBottom: '20px'}}>
        <Link href="/products" style={{color: '#4a5568'}}>Back to Products</Link>
      </div>
      <article>
        <div style={{display: 'flex', flexDirection: 'column', gap: '20px', alignItems: 'center', marginBottom: '20px'}}>
          <h1 style={{fontSize: '2rem', marginBottom: '10px'}}>{product.name}</h1>
          <div style={{maxWidth: '400px', maxHeight: '400px', display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
            <img src={product.image} alt={product.name} style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
          </div>
        </div>
        <div style={{marginBottom: '20px'}}>
          <p><strong>Category:</strong> {product.category}</p>
          <p><strong>Price:</strong> ${product.price}</p>
        </div>
        <section>
          <h2 style={{fontSize: '1.5rem', marginBottom: '10px'}}>Description</h2>
          <p>{product.description}</p>
        </section>
        <div style={{marginTop: '30px'}}>
          <a 
            href="#" 
            target="_blank" 
            rel="noopener noreferrer"
            style={{
              display: 'inline-block',
              padding: '10px 20px',
              backgroundColor: '#4a5568',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px',
              fontWeight: 'bold'
            }}
          >
            Buy Now
          </a>
        </div>
      </article>
    </div>
  );
}
