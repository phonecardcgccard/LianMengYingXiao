import Link from 'next/link';

// Placeholder for product data - in a real app, this would come from a database or API
const products = [
  { id: '1', name: 'Rose Quartz', category: 'Healing Crystals', price: '25.99', image: '/images/rose-quartz.jpg', description: 'Rose Quartz is the stone of universal love. It restores trust and harmony in relationships, encouraging unconditional love.' },
  { id: '2', name: 'Amethyst Cluster', category: 'Decorative Crystals', price: '45.50', image: '/images/amethyst-cluster.jpg', description: 'Amethyst is a powerful and protective stone. It guards against psychic attack, transmuting the energy into love and protecting the wearer from all types of harm.' },
  { id: '3', name: 'Clear Quartz Point', category: 'Energy Crystals', price: '18.75', image: '/images/clear-quartz-point.jpg', description: 'Clear Quartz is known as the master healer and will amplify energy and thought, as well as the effect of other crystals.' },
  { id: '4', name: 'Citrine Geode', category: 'Abundance Crystals', price: '62.00', image: '/images/citrine-geode.jpg', description: 'Citrine attracts wealth, prosperity and success. It imparts joy, wonder, delight and enthusiasm.' },
  { id: '5', name: 'Black Tourmaline', category: 'Protection Crystals', price: '33.25', image: '/images/black-tourmaline.jpg', description: 'Black Tourmaline is a protective stone which repels and blocks negative energies and psychic attack. Black Tourmaline also aids in the removal of negative energies within a person or a space.' }
];

export default function ProductsPage() {
  return (
    <div style={{padding: '20px', maxWidth: '1000px', margin: '0 auto'}}>
      <h1>Our Crystal Collection</h1>
      <p>Browse our carefully selected crystals, each with unique properties and benefits.</p>
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '20px', marginTop: '20px'}}>
        {products.map((product) => (
          <div key={product.id} style={{ border: '1px solid #ccc', borderRadius: '8px', padding: '15px', display: 'flex', flexDirection: 'column' }}>
            <div style={{height: '150px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px'}}>
              <img src={product.image} alt={product.name} style={{ maxWidth: '100%', maxHeight: '150px', objectFit: 'contain' }} />
            </div>
            <h2 style={{fontSize: '1.2rem', marginBottom: '8px'}}>{product.name}</h2>
            <p style={{margin: '4px 0'}}><strong>Category:</strong> {product.category}</p>
            <p style={{margin: '4px 0'}}><strong>Price:</strong> ${product.price}</p>
            <div style={{marginTop: 'auto', paddingTop: '10px'}}>
              <Link href={`/products/${product.id}`} style={{display: 'inline-block', padding: '8px 16px', backgroundColor: '#4a5568', color: 'white', textDecoration: 'none', borderRadius: '4px'}}>
                View Details
              </Link>
            </div>
          </div>
        ))}
      </div>
      <div style={{marginTop: '20px'}}>
        <Link href="/" style={{color: '#4a5568'}}>Back to Home</Link>
      </div>
    </div>
  );
}
