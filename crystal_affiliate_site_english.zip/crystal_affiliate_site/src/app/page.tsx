import Link from 'next/link';

// Placeholder for product data - in a real app, this would come from a database or API
const products = [
  { id: '1', name: 'Rose Quartz', category: 'Healing Crystals', price: '25.99', image: '/images/rose-quartz.jpg' },
  { id: '2', name: 'Amethyst Cluster', category: 'Decorative Crystals', price: '45.50', image: '/images/amethyst-cluster.jpg' },
  { id: '3', name: 'Clear Quartz Point', category: 'Energy Crystals', price: '18.75', image: '/images/clear-quartz-point.jpg' },
  { id: '4', name: 'Citrine Geode', category: 'Abundance Crystals', price: '62.00', image: '/images/citrine-geode.jpg' },
  { id: '5', name: 'Black Tourmaline', category: 'Protection Crystals', price: '33.25', image: '/images/black-tourmaline.jpg' }
];

export default function HomePage() {
  return (
    <div style={{padding: '20px', maxWidth: '800px', margin: '0 auto'}}>
      <h1>Welcome to Crystal Affiliate</h1>
      <p>Discover our beautiful crystal collection and find your perfect match.</p>
      <div style={{marginTop: '20px'}}>
        <Link href="/products">View Products</Link>
      </div>
    </div>
  );
}
